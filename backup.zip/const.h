#ifndef CONST_H
#define CONST_H

#define EOS	257
#define NUM	258

#endif
